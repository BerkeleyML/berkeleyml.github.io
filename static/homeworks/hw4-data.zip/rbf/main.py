import numpy as np
from lib import *


def part_a():
    # get the data
    X, y = generate_data()

    # perform linear regression
    weights = linear_regression(X, y)
    # measure error
    y_pred = X @ weights
    error = mean_squared_error(y, y_pred)
    print("Least squares error on original data:", error)
    # plot, remember to use original X to plot even if you augment
    plot_compare(X, y, y_pred, figname="ols_original.png")


    """YOUR CODE HERE"""
    # PART A: Implement the augmenting function in lib and
    # follow a similar procedure as above to plot the regression
    # for different degrees of polynomials as specified in the problem.
    """YOUR CODE ENDS"""


def part_b():
    X, y = generate_data()
    """YOUR CODE HERE"""
    # PART B: Implement the rbf augmenting function in lib and then follow
    # the same procedure as before to produce a graph of the fitted data.

    # decide on three means and variances that best represent the data
    # (look at the plot from part a to see gaussian shapes!)
    means = []
    variances = []
    X_rbf = rbf_augmentation(X, means, variances)
    """YOUR CODE ENDS"""


def main():
    part = input('Which part to run?\n')
    if part == 'a':
        part_a()
    elif part == 'b':
        part_b()
    else:
        print("Invalid part.")
        exit(1)

if __name__ == "__main__":
    main()
