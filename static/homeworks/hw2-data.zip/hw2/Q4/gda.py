"""
Author: Nathan Miller
Institution: UC Berkeley
Date: Spring 2022
Course: CS189/289A

A Template file for CS 189 Homework 3 question 8.

Feel free to use this if you like, but you are not required to!
"""

# TODO: Import any dependencies
import numpy as np
import scipy.stats
import math

class GDA:
    """Perform Linear discriminant analysis."""
    def __init__(self, *args, **kwargs):
        self._fit = False

        #TODO: Possibly add new instance variables

    def evaluate(self, X, y):
        """Predict and evaluate the accuracy using zero-one loss.

        Args:
            X (np.ndarray): The feature matrix shape (n, d)
            y (np.ndarray): The true labels shape (d,)

        Returns:
            float: The accuracy loss of the learner.
        """
        #TODO: Compute predictions of trained model and calculate accuracy
        #Hint: call `predict` to simplify logic
        accuracy = None
        return accuracy

    def fit(self, X, y):
        """Train the GDA model.

        Args:
            X (np.ndarray): The feature matrix (n, d)
            y (np.ndarray): The true labels (n, d)
        """
        #TODO: Train the LDA model params based on the training data passed in
        # This will most likely involve setting instance variables that can be accessed at test time
        self._fit = True

    def predict(self, X):
        """Use the fitted model to make predictions.

        Args:
            X (np.ndarray): The feature matrix of shape (n, d)

        Returns:
            np.ndarray: The array of predictions of shape (n,)

        Raises:
            RuntimeError: If called before model is trained
        """
        if not self._fit:
            raise RuntimeError("Cannot predict for a model before `fit` is called")

        preds = None
        #TODO: Compute test-time preditions for LDA model trained in 'fit'
        return preds