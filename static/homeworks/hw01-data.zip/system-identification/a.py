import numpy as np
import scipy.io

mdict = scipy.io.loadmat("a.mat")

x = mdict['x']
u = mdict['u']

# Your code to compute a and b
