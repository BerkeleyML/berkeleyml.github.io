import numpy as np
import matplotlib.pyplot as plt
from scipy.linalg import fractional_matrix_power

#################
# Generate Data #
#################

num_points = 100

sigH = 3.5
sigNx = 2
sigNy = 3

Hx = np.sort(np.random.randn(num_points,1)) * sigH
Hy = Hx

Nx = np.random.randn(num_points,1) * sigNx
Ny = np.random.randn(num_points,1) * sigNy

t = np.asarray([[1,0.5],[0.5,1]])
X = np.hstack((Hx,Nx)) @ t
t = np.asarray([[1,-0.5],[-0.5,1]])
Y = np.hstack((Hy,Ny)) @ t