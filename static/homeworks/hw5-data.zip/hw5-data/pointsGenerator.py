import numpy as np
import matplotlib.pyplot as plt

#################
# Generate Data #
#################

num_points = 50
x = np.linspace(-10,10,num_points)

#Dataset 1
X_1 = np.vstack((x,np.zeros(num_points))).T
#Dataset 2
X_2 = np.vstack((x,0.3*x)).T
#Dataset 3
X_3 = np.vstack((x,0.6*x)).T
#Dataset 4
X_4 = np.vstack((x,x)).T + np.random.randn(num_points,2)
#Dataset 5
x_abs = abs(x)
X_5 = np.vstack((x_abs*np.cos(4*x_abs),x_abs*np.sin(4*x_abs))).T
#Dataset 6
t = np.linspace(0,359,num_points) * np.pi/180
X_6 = np.vstack((10*np.cos(t),5*np.sin(t))).T
cs = np.cos(-np.pi/4)
ss = np.sin(-np.pi/4)
X_6 = X_6 @ np.asarray([[cs,-ss],[ss,cs]])
X_6 = X_6 + np.random.randn(num_points,2) * 0.5