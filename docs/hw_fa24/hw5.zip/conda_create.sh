conda create --name cs189_hw5 python=3.8 numpy pydot scikit-learn scipy pandas
